Flask-JWT
==============

.. image:: https://secure.travis-ci.org/mattupstate/flask-jwt.png?branch=master

.. image:: https://pypip.in/v/Flask-JWT/badge.png
    :target: https://pypi.python.org/pypi/Flask-JWT/
    :alt: Latest Version

.. image:: https://coveralls.io/repos/mattupstate/flask-jwt/badge.png?branch=master
    :target: https://coveralls.io/r/mattupstate/flask-jwt

.. image:: https://pypip.in/d/Flask-JWT/badge.png
    :target: https://pypi.python.org/pypi//Flask-JWT/
    :alt: Downloads

.. image:: https://pypip.in/license/Flask-JWT/badge.png
    :target: https://pypi.python.org/pypi/Flask-JWT/
    :alt: License

JWT (JSON Web Tokens) for Flask applications


Resources
---------

- `Documentation <http://packages.python.org/Flask-JWT/>`_
- `Issue Tracker <http://github.com/mattupstate/flask-jwt/issues>`_
- `Code <http://github.com/mattupstate/flask-jwt/>`_
- `Development Version
  <http://github.com/mattupstate/flask-jwt/zipball/develop#egg=Flask-JWTy-dev>`_
